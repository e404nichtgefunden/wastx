# FITUR WA KECEE BOT - by @kecee_pyrite

## POWER TOOLS VIA WHATSAPP
✔ .cmd <command>  → Eksekusi langsung di VPS (main process)
✔ .flood <args>   → Jalankan tool flooder ./stx
✔ .adduser <jid>  → Tambah user yang boleh akses bot
✔ .deluser <jid>  → Hapus user dari whitelist
✔ .addbot <jid>   → Auto jalankan bot baru dengan WA pairing sendiri
✔ .help           → Lihat semua menu dari WhatsApp

## MULTIBOT SYSTEM
- Jalankan beberapa WA bot dalam 1 VPS
- Setiap bot punya WA berbeda
- Siap dikendalikan dari WhatsApp

## FITUR TAMBAHAN
- Auto-restart via systemd
- Shell installer: ./run_kecee.sh
- Token pairing (tanpa kamera)
- Bot selalu aktif meski VPS reboot
- Semua command dijalankan sebagai MAIN PROCESS

## FILE DALAM ZIP
- index_baileys.js → Bot utama
- flooderbot.js    → Bot tambahan
- auth_sub.json    → Auth template
- stx              → Flooder binary
- run_kecee.sh     → Installer otomatis
- package.json     → Dependency lengkap
- README.md        → Setup bot
- FITUR.md         → Penjelasan fitur ini

🔥 Dibangun oleh JungkerGPT x @kecee_pyrite - NO ERROR NO YAPPING CLUB.